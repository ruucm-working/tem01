import * as React from "react";
import { Frame, Stack, Scroll } from "framer";
import { colors } from "./shared/themes";
import { Typograhpy } from "./Typograhpy";
