import * as React from "react";
import { Frame, addPropertyControls, ControlType } from "framer";
import { Typograhpy } from "./Typograhpy";

export function Text({ prop1, ...rest }) {
  return (
    <Frame>
      <Typograhpy theme="header-emphasized" text="title" children="" />
    </Frame>
  );
}

Text.defaultProps = {
  prop1: "Default prop1 Value"
};

addPropertyControls(Text, {
  prop1: {
    type: ControlType.String
  }
});
