import * as React from "react";
import { Frame } from "framer";

export function PlayerContainer(props) {
  return <Frame width={props.width}></Frame>;
}

PlayerContainer.defaultProps = {
  width: 414
};
