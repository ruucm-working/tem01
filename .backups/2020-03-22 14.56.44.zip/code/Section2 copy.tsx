import * as React from "react";
import { Frame, Stack, Scroll } from "framer";
import { Play, Forward } from "./assets/Icons/index";

import { colors } from "./shared/themes";
import { Typograhpy } from "./Typograhpy";
import { Song } from "./Song";
import { ScrollComp } from "./Scroll";

export function Sec23(props) {
  return (
    <Stack
      width={props.width}
      height={props.height}
      background=""
      gap={0}
      distribution="start"
      center="x"
    >
      <Stack
        style={{
          borderTop: `1px solid ${colors.borderColor}`
        }}
        width={props.width - 40}
        height=""
        direction="horizontal"
        distribution="space-between"
        background="pink"
      >
        <Typograhpy text="Must Have" type="shelf-title" />
        <Typograhpy text="See all" type="see-all" />
      </Stack>
      {/* <Frame
        width="100%"
        height={props.height - 48}
        style={{
          padding: "0px"
        }}
      > */}
      <ScrollComp />
      {/* </Frame> */}
    </Stack>
  );
}

Sec23.defaultProps = {
  width: 414,
  height: 310
};
