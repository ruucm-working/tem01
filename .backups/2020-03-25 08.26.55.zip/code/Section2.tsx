import * as React from "react";
import { Frame, Stack, Scroll } from "framer";
import { Play, Forward } from "./assets/Icons/index";

import { colors } from "./shared/themes";
import { Typograhpy } from "./Typograhpy";
import { Song } from "./Song";

export function Sec2(props) {
  return (
    <Frame width={props.width} height={props.height} background="">
      <Stack
        width={props.width - 40}
        gap={0}
        center="x"
        style={{
          borderTop: `1px solid ${colors.borderColor}`
        }}
      >
        <Stack
          width="100%"
          height="40px"
          direction="horizontal"
          distribution="space-between"
        >
          <Typograhpy text="Must Have" type="shelf-title" />
          <Typograhpy text="See all" type="see-all" />
        </Stack>
        <Scroll
          background="blue"
          direction="horizontal"
          width="100%"
          height={props.height - 48}
        >
          <Stack direction="horizontal" width="100%" background="pink">
            <Song />
            <Song />
            <Song />
            <Song />
          </Stack>
        </Scroll>
      </Stack>
    </Frame>
  );
}

Sec2.defaultProps = {
  width: 414,
  height: 300
};
