import * as React from 'react'

export function List({ color }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
      <path
        fill={color}
        fillRule="evenodd"
        d="M3.384 5.438h.692a1.04 1.04 0 110 2.078h-.692a1.04 1.04 0 110-2.079zm4.157 0h13.165a1.04 1.04 0 110 2.078H7.541a1.04 1.04 0 010-2.079zM3.384 10.98h.692a1.04 1.04 0 010 2.08h-.692a1.04 1.04 0 010-2.08zm4.157 0h13.165a1.04 1.04 0 010 2.08H7.541c-.573 0-1.04-.466-1.04-1.04 0-.573.467-1.04 1.04-1.04zm-4.157 5.544h.692a1.04 1.04 0 110 2.079h-.692a1.04 1.04 0 110-2.079zm4.157 0h13.165a1.04 1.04 0 110 2.079H7.541a1.04 1.04 0 010-2.079z"
        clipRule="evenodd"
      />
    </svg>
  )
}

List.defaultProps = {
  width: 24,
  height: 24,
  color: '#000',
}
