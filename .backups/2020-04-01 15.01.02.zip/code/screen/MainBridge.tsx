import * as React from "react";
import { Frame, addPropertyControls, ControlType, Stack, Page } from "framer";
import { StatusBar } from "../Status";
import { Header } from "../components/Header";
import { MainSection } from "../components/MainSection";
import { SongSection } from "../components/SongSection";

export function Comp1({ prop1, ...rest }) {
  return (
    <Stack width={414} height={896} gap={0}>
      <StatusBar appearance={"dark"} />
      <Header text={"Browse"} />
      <Page
        width={414}
        height={340}
        gap={10}
        contentWidth="auto"
        style={{
          paddingLeft: "20px",
          marginBottom: "20px"
        }}
        //   contentHeight="auto"
      >
        <MainSection />
        <MainSection />
        <MainSection />
        <MainSection />
      </Page>
      <SongSection />
    </Stack>
  );
}

Comp1.defaultProps = {
  prop1: "Default prop1 Value"
};

addPropertyControls(Comp1, {
  prop1: {
    type: ControlType.String
  }
});
