import * as React from "react";
import { Frame, addPropertyControls, ControlType } from "framer";
import { Typograhpy } from "../Typograhpy";

export function Header(props) {
  return (
    <Frame width={props.width} height={props.height} background="" {...props}>
      <Typograhpy text={props.text} type={props.type} />
    </Frame>
  );
}

Header.defaultProps = {
  width: "100%",
  height: 40,
  text: "Browse",
  type: "header-emphasized"
};

addPropertyControls(Header, {
  type: {
    type: ControlType.String
  },
  text: {
    type: ControlType.String
  }
});
