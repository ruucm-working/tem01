import * as React from "react";
import { Frame, Page, addPropertyControls, ControlType } from "framer";
import { Header } from "../components/Header";

export function Browse({ prop1, ...rest }) {
  return (
    <Page>
      <Frame>
        <Header />
      </Frame>
    </Page>
  );
}

Browse.defaultProps = {
  prop1: "Default prop1 Value"
};

addPropertyControls(Browse, {
  prop1: {
    type: ControlType.String
  }
});
