import * as React from "react";
import { Frame, addPropertyControls, ControlType, Stack } from "framer";
import { StatusBar } from "../Status";
import { Header } from "../components/Header";
import { MainSection } from "../components/MainSection";
import { SongSection } from "../components/SongSection";

export function Comp1({ prop1, ...rest }) {
  return (
    <Stack width={414} height={896} gap={0}>
      <StatusBar appearance={"dark"} />
      <Header text={"Browse"} />
      <MainSection />
      <SongSection />
    </Stack>
  );
}

Comp1.defaultProps = {
  prop1: "Default prop1 Value"
};

addPropertyControls(Comp1, {
  prop1: {
    type: ControlType.String
  }
});
