import * as React from "react";
import { Frame, Page, addPropertyControls, ControlType, Stack } from "framer";
import { Header } from "../components/Header";
import { MainSection } from "../components/MainSection";
import { SongSection } from "../components/SongSection";

export function Browse({ prop1, ...rest }) {
  return (
    <Page width={414} height={812}>
      <Stack width="100%" height="100%" direction="vertical">
        <Frame width="100%" height={100} style={{ paddingLeft: "20px" }}>
          <Header bottom={5} />
        </Frame>
        <Page
          width="100%"
          height={340}
          contentOffsetX={20}
          contentWidth={414 - 20}
          gap={20}
        >
          <MainSection />
          <MainSection />
        </Page>

        <SongSection />
      </Stack>
    </Page>
  );
}

Browse.defaultProps = {
  prop1: "Default prop1 Value"
};

addPropertyControls(Browse, {
  prop1: {
    type: ControlType.String
  }
});
