import * as React from "react";
import { Frame, Stack } from "framer";
import { colors } from "../shared/themes";
import { Typograhpy } from "../Typograhpy";
import { Play, Forward } from "../assets/Icons";

export function PlayerContainer(props) {
  return (
    <Stack width={props.width} background="" gap={0}>
      <Frame width="100%" height={props.width} background="">
        <Frame
          center
          size="280px"
          style={{
            borderRadius: "5px",
            shadow: `1px 1px 10px 5px ${colors.playerDropShadow2}`,
            backgroundSize: "cover",
            backgroundImage: `url("https://pgnqdrjultom1827145.cdn.ntruss.com/img/66/ba/66babea39e17dd90c66d6b8a13ba982a841032ea31dad8d4a56bd29d8e5d988c_v1.jpg")`
          }}
        ></Frame>
      </Frame>

      {/* title */}
      <Frame width="100%" height="73px">
        <Stack
          width={props.width - 60}
          height="100%"
          center
          direction="horizontal"
        >
          <Stack
            width="4fr"
            height="100%"
            alignment="start"
            distribution="center"
          >
            <Typograhpy text="Power" type="title-emphasized" />
            <Typograhpy text="Kanye West" type="title" />
          </Stack>
          <Frame width="1fr" height="100%"></Frame>
        </Stack>
      </Frame>

      {/* time */}
      <Frame width="100%" height="54px">
        <Frame width={props.width - 60} height="" center></Frame>
      </Frame>

      {/* control */}
      <Frame width="100%" height="141px">
        <Stack
          width={props.width - 100}
          height="100%"
          center
          direction="horizontal"
          gap={0}
        >
          <Frame width="1fr" height="100%">
            <Frame width="70%" height="" center rotate={180}>
              <Forward />
            </Frame>
          </Frame>
          <Frame width="2fr" height="100%">
            <Frame width="40%" height="" center>
              <Play />
            </Frame>
          </Frame>
          <Frame width="1fr" height="100%">
            <Frame width="70%" height="" center>
              <Forward />
            </Frame>
          </Frame>
        </Stack>
      </Frame>

      {/* volume */}
      <Frame width="100%" height="54px">
        <Frame width={props.width - 60} height="" center></Frame>
      </Frame>

      {/* bottom */}
    </Stack>
  );
}

PlayerContainer.defaultProps = {
  width: 414
};
