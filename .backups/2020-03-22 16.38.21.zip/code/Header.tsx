import * as React from "react";
import { Frame } from "framer";
import { Typograhpy } from "./Typograhpy";

export function Header(props) {
  return (
    <Frame width="" height="" background="">
      <Typograhpy text="Browse" type="header-emphasized" />
    </Frame>
  );
}
