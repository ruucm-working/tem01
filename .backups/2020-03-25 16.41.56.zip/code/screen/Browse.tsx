import * as React from "react";
import { Frame, Page, addPropertyControls, ControlType, Stack } from "framer";
import { Header } from "../components/Header";

export function Browse({ prop1, ...rest }) {
  return (
    <Page>
      <Stack width={414} height={812} direction="vertical">
        <Frame width={414} height={100} style={{ paddingLeft: "20px" }}>
          <Header bottom={5} left={0} />
        </Frame>
      </Stack>
    </Page>
  );
}

Browse.defaultProps = {
  prop1: "Default prop1 Value"
};

addPropertyControls(Browse, {
  prop1: {
    type: ControlType.String
  }
});
