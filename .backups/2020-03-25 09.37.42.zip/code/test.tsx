
import * as React from "react";
import { Frame, addPropertyControls, ControlType } from "framer";

export function Comp0({prop1, ...rest}) {
  return <Frame>{prop1}</Frame>;
}

Comp0.defaultProps = {
  prop1: "Default prop1 Value"
};

addPropertyControls(Comp0, {
  prop1: {
    type: ControlType.String
  }
});
