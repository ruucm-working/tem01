import * as React from "react";
import { Frame, Stack } from "framer";
import { colors } from "../shared/themes";

export function PlayerContainer(props) {
  return (
    <Stack width={props.width} background="" gap={0}>
      <Frame width="100%" height={props.width} background="">
        <Frame
          center
          size="280px"
          style={{
            borderRadius: "5px",
            shadow: `1px 1px 10px 5px ${colors.playerDropShadow2}`,
            backgroundSize: "cover",
            backgroundImage: `url("https://pgnqdrjultom1827145.cdn.ntruss.com/img/66/ba/66babea39e17dd90c66d6b8a13ba982a841032ea31dad8d4a56bd29d8e5d988c_v1.jpg")`
          }}
        ></Frame>
      </Frame>
      <Frame width="100%" height="73px">
        <Stack width={props.width - 60} height="100%" center>
          <Stack width="4fr"></Stack>
          <Frame width="1fr"></Frame>
        </Stack>
      </Frame>
    </Stack>
  );
}

PlayerContainer.defaultProps = {
  width: 414
};
